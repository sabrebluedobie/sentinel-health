import React from 'react'; export const Label = ({className='',...p})=> <label {...p} className={`text-sm font-medium ${className}`} />;
