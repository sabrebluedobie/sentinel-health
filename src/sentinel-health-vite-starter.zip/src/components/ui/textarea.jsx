import React from 'react'; export const Textarea = (p)=> <textarea {...p} className={`w-full rounded-md border px-3 py-2 text-sm ${p.className||''}`} />;
