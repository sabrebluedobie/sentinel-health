import React from 'react'; export const Skeleton = ({className=''})=> <div className={`animate-pulse rounded-md bg-gray-200 ${className}`} />;
