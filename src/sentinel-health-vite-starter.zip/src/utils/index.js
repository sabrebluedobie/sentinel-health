export const createPageUrl = (name) => `/${name}`;
